from math import sqrt
ymax_game :int = 800
xmax_game :int = 800
xmax_stat :int = xmax_game//2
xmax :int = xmax_game+xmax_stat
nb_carre :int = 16
nb_carre_x = nb_carre
nb_carre_y = nb_carre
taille_carre :int = xmax_game
taille_carre_x = int(xmax_game//nb_carre_x)
taille_carre_y = int(ymax_game//nb_carre_y)
play :bool = True  # A mettre sur faux pour couper le jeu | interrupteur général
condi :bool = False
taille_spawn_x :int = round(sqrt(nb_carre_x))
taille_spawn_y :int = round(sqrt(nb_carre_y))
# --------------------------------------
# Configuration des limite de fin de jeu
time_out = 300 # nb de tour max 
# ----------------------------------
# Configuration de l'interface de graphique
map_default_color_black = 'black'
map_default_color_white = 'white'
spawn_equipe_1bk :str = 'green'
spawn_equipe_1wh :str = "light green"
spawn_equipe_2bk :str = 'blue'
spawn_equipe_2wh :str = 'DeepSkyBlue'
spawn_equipe_3bk :str = 'dark violet'
spawn_equipe_3wh :str = 'purple'
spawn_equipe_4bk :str = 'red'
spawn_equipe_4wh :str = 'indian red'
map_error_color :str = 'orange'
map_flower_color :str = "DeepPink2"
map_player_color :str = "navy" # n'est plus utilisé actuellement -> /image/abeille_menu.png
map_color_flower :str = "cyan"
# ---------------------------
# Gestion des Abeilles et joueur
id_actuelle :int = 0
id_actuelle_joueur :int = 0
# voir backend pour les joueur
# ----------------------------
# Gestion des fleurs
nectar_initial :int = 10
nectar_par_butinage = 3
max_nectar :int = 45
nb_fleur :int = nb_carre//4 # Doit être divisible /4
# ---------------------------
# Gestion des Image des spawn
taille_image_spawn :int = 50
# --------------------------
# Pre-lunch Inf
taille_mini :int = 300
taille_texture_abeille :int = 50 # taille de la texture abeille_menu.png
# -----------------------
# Verification des règles de configuration
if max_nectar % 3 != 0:
    assert(f"Problème de configuration : Le nectar max n'est pas Disivible par 3 | Valeur Acteuelle : {max_nectar}")
if nb_carre % 2 != 0:
    assert(f"Problème de configuration : Le Nombre de Cases n'est pas Disivible par 2 | Valeur Acteuelle : {nb_carre}")
if time_out % 4 != 0:
    assert(f"Problème de configuration : Le nombre de tour max ( Time out ) n'est pas Disivible par 4 | Valeur Acteuelle : {time_out}")
if nb_fleur % 4 != 0:
    assert(f"Problème de configuration : Le nombre de fleur n'est pas Disivible par 4 | Valeur Acteuelle : {nb_fleur}")