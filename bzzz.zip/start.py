import lib_graphisme
lib_graphisme.menu()